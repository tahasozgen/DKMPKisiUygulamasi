﻿using AutoMapper;
using DKMPKisiUygulamasi.Model.EnumKlasoru;
using DKMPKisiUygulamasi.WCF.Somut;
using DKMPKisiUygulamasi.WCF.ViewModelKlasor.Somut.VarlikKlasor.KisiKlasor;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKMPKisiUygulamasi.WCF.AltyapiKlasoru.CevirmeKlasoru.ResolverKlasoru
{
    class CalismaDurumuResolver : ITypeConverter<CalismaDurumu, CalismaDurumuViewModel>
    {
        public CalismaDurumuViewModel Convert(CalismaDurumu source, CalismaDurumuViewModel destination, ResolutionContext context)
        {
            string aciklama = Arac.DescriptionAttr<CalismaDurumu>(source);
            int anahtar = (int)source;
            return new CalismaDurumuViewModel(anahtar, aciklama);
        }
    }
}
