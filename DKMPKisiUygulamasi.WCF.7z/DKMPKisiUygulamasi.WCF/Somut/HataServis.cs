﻿using DKMPKisiUygulamasi.WCF.Soyut;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DKMPHataAltyapi;

namespace DKMPKisiUygulamasi.WCF.Somut
{
    public class HataServis : IHataServis
    {

        private readonly HataServis _hataServis;

        public HataServis()
        {
            this._hataServis = new HataServis();
        }

        public void YazHata(UIHata hata)
        {
            try
            {
                if (hata != null)
                    this._hataServis.YazHata(hata);
            }
            catch (Exception yeniHata)
            {
                this._hataServis.YazHata(yeniHata);
            }
        }

        public void YazHata(Exception hata)
        {
            try
            {
                if (hata != null)
                    this._hataServis.YazHata(hata);
            }
            catch (Exception yeniHata)
            {
                this._hataServis.YazHata(yeniHata);
            }
        }
    }
}
