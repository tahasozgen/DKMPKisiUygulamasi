﻿
using DKMPKisiUygulamasi.WCF.ViewModelKlasor.Soyut;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKMPKisiUygulamasi.WCF.ViewModelKlasor.Somut.VarlikKlasor.TanimlayiciKlasor
{
    public class EgitimDuzeyiViewModel : SozlukViewModel
    {
        protected EgitimDuzeyiViewModel() : base()
        {

        }

        public EgitimDuzeyiViewModel(int anahtar, string adi) : base(anahtar,adi)
        {

        }
    }
}
