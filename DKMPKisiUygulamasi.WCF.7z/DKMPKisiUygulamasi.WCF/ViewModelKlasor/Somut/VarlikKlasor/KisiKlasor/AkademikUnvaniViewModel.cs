﻿using DKMPKisiUygulamasi.WCF.ViewModelKlasor.Soyut;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKMPKisiUygulamasi.WCF.ViewModelKlasor.Somut.VarlikKlasor.KisiKlasor
{
    public class AkademikUnvaniViewModel : SozlukViewModel
    {
        protected AkademikUnvaniViewModel() : base()
        {

        }

        public AkademikUnvaniViewModel(int anahtar, string adi) : base(anahtar,adi)
        {

        }


    }
}
