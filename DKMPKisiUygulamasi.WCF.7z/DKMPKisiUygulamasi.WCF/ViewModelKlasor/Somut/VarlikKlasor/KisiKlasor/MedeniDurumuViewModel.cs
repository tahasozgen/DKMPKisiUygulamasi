﻿using DKMPKisiUygulamasi.WCF.ViewModelKlasor.Soyut;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKMPKisiUygulamasi.WCF.ViewModelKlasor.Somut.VarlikKlasor.KisiKlasor
{
    public class MedeniDurumuViewModel : SozlukViewModel
    {
        protected MedeniDurumuViewModel() : base()
        {

        }

        public MedeniDurumuViewModel(int anahtar, string adi) : base(anahtar,adi)
        {


        }
    }
}
