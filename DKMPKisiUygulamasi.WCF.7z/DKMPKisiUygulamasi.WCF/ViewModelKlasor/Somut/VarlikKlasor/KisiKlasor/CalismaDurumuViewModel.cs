﻿using DKMPKisiUygulamasi.WCF.ViewModelKlasor.Soyut;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKMPKisiUygulamasi.WCF.ViewModelKlasor.Somut.VarlikKlasor.KisiKlasor
{
    public class CalismaDurumuViewModel : SozlukViewModel
    {
        protected CalismaDurumuViewModel() : base()
        {

        }

        public CalismaDurumuViewModel(int anahtar, string adi) : base(anahtar,adi)
        {

        }
    }
}
